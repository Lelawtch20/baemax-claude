# B.A.Y.M.A.X (Baymax Care Station) - complete (all 5 steps)

## How to run
Chrome blocks ES modules, model loading, camera and Web Serial on `file://`, so
double-clicking index.html will NOT work. Use a tiny local server instead:
1. Install Python, open a terminal in this folder.
2. Run `python -m http.server 8000`
3. Open http://localhost:8000 in Chrome (localhost counts as secure: camera and Web Serial work).

## Where to edit
- Title, idle timeout, emergency number: `js/config.js`
- All text (English + Filipino): `js/ui/i18n.js`
- Colors: top of `css/styles.css`
- Font: Nunito is used if installed on the laptop, otherwise the system sans-serif.

## Demo mode (no hardware)
Open http://localhost:8000/?demo (or set `DEMO_MODE: true` in `js/config.js`). The hidden settings menu comes in step 5.

## ESP32 (Web Serial, Chrome, 115200 baud)
Send one JSON line per reading:
`{"type":"spo2","spo2":97,"pulse":78}`, `{"type":"temp","c":36.8}`, `{"type":"bp","sys":120,"dia":80,"pulse":72}`.
Tap "Connect device" on a reading screen. Impossible values are rejected (limits in `js/sensors/validate.js`).
"Lock in reading" averages the last up to 10 values (needs at least 5).

## Thresholds and expected results
Edit numbers in `js/engine/thresholds.js` (a nurse should validate them). BMI and the skin check are shown but never change the overall level.
- BP 118/76, SpO2 98, temp 36.6 -> Normal
- BP 145/92, SpO2 93, temp 38.2 -> Needs attention
- SpO2 88 -> Urgent (Emergency screen first)
- BP 190/125 -> Urgent
Optional online advice: set `LLM_ENDPOINT` in `js/config.js` to your own proxy (never put an API key in the browser code).

## Skin check (camera + model)
Put your Teachable Machine export in `model/` (see `model/README.md`). For fully offline use add the two library files in `libs/` (see `libs/README.md`). Below 70% confidence Baymax says "I am not sure" (`THRESHOLD` in `js/engine/classifier.js`). Images are drawn to a hidden canvas, classified, then wiped; nothing is stored or uploaded.

## Hidden settings
Tap the Baymax face 5 times (within 3 seconds): demo mode, connect device, voice, text size, threshold viewer (read-only), simulate camera model.

## Testing checklist
- [ ] Tap the cover, hear the greeting; Filipino toggle keeps what you typed in the patient form; mute works
- [ ] Begin is blocked on Consent until "I understand" is ticked; patient form rejects bad ranges
- [ ] `?demo`: live values on BP / Oxygen / Temperature; "Lock in reading" averages; manual entry rejects impossible values
- [ ] The four test cases above give the expected levels; Urgent shows the Emergency screen first and no advice
- [ ] Results: chips, advice is revealed and spoken, "Read aloud again", Print preview is clean, satisfaction Yes/No
- [ ] Skin: no model -> friendly message + demo mode; under 70% -> "I am not sure"
- [ ] Start new patient and the 5-minute idle timeout return to Home with all data cleared
- [ ] ESP32 on Chrome: Connect device, malformed lines ignored, unplug shows "No device connected"

## Done in step 1
Design system, SVG Baymax face (idle/listening/thinking/happy/concerned/alert), Home, Consent,
Patient info, Assessment menu (demo values), language + mute toggles, 5-minute privacy wipe.

## Choices made
- Pain scale is built in step 2 with the reading screens (menu follows patient info for now).
- Chrome only speaks after the first tap, so the Home greeting may be silent until you tap once.
- Default thresholds are for adults; the patient form still accepts ages 1-120.
