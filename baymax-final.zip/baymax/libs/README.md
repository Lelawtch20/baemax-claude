# libs folder (for fully offline use)
The skin check loads TensorFlow.js and the Teachable Machine library from the CDN if these files are missing.
To work with no internet, download these two files once and save them here with these exact names:
- tf.min.js  <- https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@1.3.1/dist/tf.min.js
- teachablemachine-image.min.js  <- https://cdn.jsdelivr.net/npm/@teachablemachine/image@0.8.5/dist/teachablemachine-image.min.js
(The browser console shows a harmless "not found" message for a local file until you add it.)
