// consent.js - Screen 2: notice + "I understand" checkbox required to continue.
export default function consent(el, app) {
  const { t } = app;
  el.innerHTML = `<h2>${t("consentTitle")}</h2>
    <div class="card"><ul>${["c1", "c2", "c3", "c4"].map((k) => `<li>${t(k)}</li>`).join("")}</ul></div>
    <label class="check"><input type="checkbox" id="ok"> ${t("understand")}</label>
    <div class="row"><button class="pill ghost" id="back">${t("back")}</button>
    <button class="pill" id="next" disabled>${t("next")}</button></div>`;
  const ok = el.querySelector("#ok"), next = el.querySelector("#next");
  ok.onchange = () => (next.disabled = !ok.checked);
  el.querySelector("#back").onclick = () => app.go("home");
  next.onclick = () => app.go("patient");
  app.face.set("listening");
  app.speak(t("speakConsent"));
}
