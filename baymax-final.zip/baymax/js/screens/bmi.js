// bmi.js - Screen 9: BMI from height/weight (editable) + colored scale bar (15 to 35).
// Cutoffs are in js/engine/thresholds.js.
import { bmiClass } from "../engine/thresholds.js";
const SEG = [[17.5, "var(--warn)"], [22.5, "var(--ok)"], [10, "var(--warn)"], [25, "var(--warn)"], [25, "var(--bad)"]]; // widths in % of 15-35
export default function bmi(el, app) {
  const { t, state } = app, p = state.patient;
  el.innerHTML = `<h2>${t("bmi")}</h2><div class="fields">
    <div><label for="h">${t("height")}</label><input id="h" type="number" inputmode="decimal" value="${p.height}"></div>
    <div><label for="w">${t("weight")}</label><input id="w" type="number" inputmode="decimal" value="${p.weight}"></div></div>
    <div class="card center"><p>${t("yourBmi")}: <strong id="v"></strong> <span id="c"></span></p>
    <div class="bmibar" aria-hidden="true">${SEG.map(([w, c]) => `<i style="width:${w}%;background:${c}"></i>`).join("")}<b class="mark" id="m"></b></div></div>
    <div class="row"><button class="pill ghost" id="back">${t("back")}</button><button class="pill" id="save">${t("save")}</button></div>`;
  const $ = (s) => el.querySelector(s);
  const calc = () => { const h = +$("#h").value, w = +$("#w").value;
    return h >= 50 && h <= 250 && w >= 10 && w <= 300 ? +(w / (h / 100) ** 2).toFixed(1) : null; };
  const update = () => { const b = calc();
    $("#v").textContent = b ?? "--"; $("#c").textContent = b ? "(" + t(bmiClass(b)) + ")" : "";
    $("#m").style.left = b ? Math.min(100, Math.max(0, ((b - 15) / 20) * 100)) + "%" : "-10%"; $("#save").disabled = !b; };
  $("#h").oninput = $("#w").oninput = update;
  $("#back").onclick = () => app.go("menu");
  $("#save").onclick = () => { const b = calc(); p.height = +$("#h").value; p.weight = +$("#w").value;
    state.readings.bmi = { bmi: b, text: `${b} (${t(bmiClass(b))})` }; app.go("menu"); };
  update(); app.face.set("idle"); app.speak(t("speakBmi"));
}
