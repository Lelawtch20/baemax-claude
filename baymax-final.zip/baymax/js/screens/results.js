// results.js - Screen 11: summary chips, Baymax Advice (hidden when urgent), print, satisfaction.
import { assess } from "../engine/assess.js";
import { getAdvice } from "../engine/advice.js";
import { tx } from "../engine/text.js";
import { getLang } from "../ui/i18n.js";
const CHIP = { normal: "ok", caution: "warn", urgent: "bad" };
export default function results(el, app) {
  const { t, state } = app, lang = getLang(), a = assess(state), urgent = a.overall === "urgent";
  el.innerHTML = `<h2>${t("resultsTitle")}: <span class="cs ${a.overall === "normal" ? "ok" : urgent ? "bad" : "warn"}">${t("lvl_" + a.overall)}</span></h2>
    ${urgent ? `<p class="alarm-s">${t("emMsg")} ${t("call")} 911</p>` : ""}
    <div class="card"><ul class="sum">${a.items.map((i) => `<li><span class="cs ${CHIP[i.status]}">${t("st_" + i.status)}</span>
      <strong>${t(i.key === "pain" ? "painLbl" : i.key)}: ${i.value}</strong><br>${tx(lang, i.key + "_" + i.code)}</li>`).join("")}</ul></div>
    <div class="card" id="adv"${urgent ? " hidden" : ""}><h3>${t("adviceTitle")}</h3><p id="advt" aria-live="polite"></p>
      <button class="pill ghost no-print" id="again">${t("again")}</button></div>
    <p class="no-print" id="sat">${t("satisfied")} <button class="pill small" id="yes">${t("yes")}</button> <button class="pill small" id="no">${t("no")}</button></p>
    <div class="row no-print"><button class="pill ghost" id="print">${t("print")}</button><button class="pill" id="new">${t("newPatient")}</button></div>`;
  const $ = (s) => el.querySelector(s);
  let chunks = [], gone = false; const timers = [];
  const p = state.patient || {}, d = Math.floor((p.age || 0) / 10) * 10;
  const summary = { ageRange: `${d}-${d + 9}`, sex: p.sex, symptoms: state.symptoms, overall: a.overall, // no name is ever sent
    readings: a.items.map((i) => ({ key: i.key, value: i.value, status: i.status })) };
  if (urgent) app.face.set("alert");
  else {
    app.face.set("thinking"); $("#advt").textContent = t("thinking");
    Promise.all([getAdvice(summary, lang), new Promise((r) => setTimeout(r, 900))]).then(([c]) => {
      if (gone) return;
      chunks = c; $("#advt").textContent = ""; app.face.set(a.overall === "normal" ? "happy" : "concerned");
      c.forEach((s, i) => timers.push(setTimeout(() => { $("#advt").textContent += (i ? " " : "") + s; }, i * 1500)));
      app.speak(c.join(" "));
    });
  }
  $("#again").onclick = () => app.speak(chunks.join(" "));
  const vote = (v) => { state.satisfied = v; $("#sat").textContent = t("thanks"); };
  $("#yes").onclick = () => vote(true); $("#no").onclick = () => vote(false);
  $("#print").onclick = () => window.print();
  $("#new").onclick = () => app.reset();
  return () => { gone = true; timers.forEach(clearTimeout); };
}
