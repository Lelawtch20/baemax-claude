// menu.js - Screen 5: six cards. Tap a card to open its reading screen.
// The skin check is a demo toggle until step 4 adds the camera screen.
import { assess } from "../engine/assess.js";
const TILES = ["bp", "spo2", "temp", "bmi", "skin"];
export default function menu(el, app) {
  const { t, state } = app;
  el.innerHTML = `<h2 class="center">${t("menuTitle")}</h2><p class="note center">${t("demoNote")}</p>
    <div class="grid" id="g"></div><p class="note center" id="msg" role="status"></p>
    <div class="row"><button class="pill ghost" id="over">${t("startOver")}</button></div>`;
  const g = el.querySelector("#g"), msg = el.querySelector("#msg");
  g.innerHTML = TILES.map((k) => { const r = state.readings[k];
    return `<button class="tile" data-k="${k}" aria-pressed="${!!r}"><strong>${t(k)}</strong>
      <span class="badge${r ? " done" : ""}">${r ? t("done") + ": " + r.text : t("notDone")}</span></button>`; }).join("")
    + `<button class="pill" id="get"${Object.keys(state.readings).length ? "" : " disabled"}>${t("get")}</button>`;
  g.onclick = (e) => {
    const b = e.target.closest("[data-k]");
    if (b) app.go(b.dataset.k);
    else if (e.target.closest("#get")) app.go(assess(state).overall === "urgent" ? "emergency" : "results");
  };
  el.querySelector("#over").onclick = () => app.reset();
  app.face.set("idle"); app.speak(t("speakMenu"));
}
