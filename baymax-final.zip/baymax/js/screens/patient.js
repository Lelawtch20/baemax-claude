// patient.js - Screen 3: age, sex, optional name, height, weight (with range checks).
// Ranges are in LIMITS. Note: the default thresholds are for ADULTS.
const LIMITS = { age: [1, 120], height: [50, 250], weight: [10, 300] };
export default function patient(el, app) {
  const { t, state } = app, p = state.draft || state.patient || {}; // draft keeps typing when the language is switched
  const v = (x) => (x ?? "");
  el.innerHTML = `<h2>${t("patientTitle")}</h2><div class="fields">
    <div><label for="age">${t("age")}</label><input id="age" type="number" inputmode="numeric" value="${v(p.age)}"></div>
    <div><label for="sex">${t("sex")}</label><select id="sex"><option value="">${t("choose")}</option>
      <option value="M"${p.sex === "M" ? " selected" : ""}>${t("male")}</option>
      <option value="F"${p.sex === "F" ? " selected" : ""}>${t("female")}</option></select></div>
    <div><label for="height">${t("height")}</label><input id="height" type="number" inputmode="decimal" value="${v(p.height)}"></div>
    <div><label for="weight">${t("weight")}</label><input id="weight" type="number" inputmode="decimal" value="${v(p.weight)}"></div>
    </div><label for="name">${t("name")}</label><input id="name" type="text" value="${v(p.name)}">
    <p class="err" id="err" role="alert"></p>
    <div class="row"><button class="pill ghost" id="back">${t("back")}</button>
    <button class="pill" id="next">${t("next")}</button></div>`;
  const $ = (id) => el.querySelector("#" + id);
  const inRange = (k, n) => Number.isFinite(n) && n >= LIMITS[k][0] && n <= LIMITS[k][1];
  const save = () => { state.draft = { age: $("age").value, sex: $("sex").value, name: $("name").value, height: $("height").value, weight: $("weight").value }; };
  ["input", "change"].forEach((ev) => el.addEventListener(ev, save));
  $("back").onclick = () => app.go("consent");
  $("next").onclick = () => {
    const d = { age: Math.round(+$("age").value), sex: $("sex").value, name: $("name").value.trim(),
      height: +$("height").value, weight: +$("weight").value };
    const bad = !inRange("age", d.age) ? "errAge" : !d.sex ? "errSex"
      : !inRange("height", d.height) ? "errHeight" : !inRange("weight", d.weight) ? "errWeight" : "";
    $("err").textContent = bad ? t(bad) : "";
    if (!bad) { state.patient = d; app.go("pain"); }
  };
  app.face.set("listening");
  app.speak(t("speakPatient"));
}
