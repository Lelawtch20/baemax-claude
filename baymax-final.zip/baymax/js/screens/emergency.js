// emergency.js - Screen 12: shown first whenever the engine says URGENT. No casual advice here.
import { CONFIG } from "../config.js";
export default function emergency(el, app) {
  const { t } = app;
  el.innerHTML = `<div class="alarm center"><h1>${t("emTitle")}</h1><p class="big">${t("emMsg")}</p>
    <p class="big"><strong>${t("call")} ${CONFIG.EMERGENCY_NUMBER}</strong></p>
    <div class="row"><button class="pill ghost" id="rd">${t("seeReadings")}</button><button class="pill ghost" id="nw">${t("newPatient")}</button></div></div>`;
  el.querySelector("#rd").onclick = () => app.go("results");
  el.querySelector("#nw").onclick = () => app.reset();
  app.face.set("alert"); app.speak(t("emMsg"));
}
