// reading.js - shared layout for the Blood Pressure, Oxygen/Pulse and Temperature screens.
// To add a sensor: add a row to CFG and a tiny screen file like bp.js.
import { subscribe, connect, status, isDemo, serialSupported } from "../sensors/hub.js";
import { ManualProvider } from "../sensors/manual.js";
const manual = new ManualProvider();
const CFG = {
  bp: { type: "bp", keys: ["sys", "dia", "pulse"], labels: { sys: "sys", dia: "dia", pulse: "pulse" }, instr: "instrBp", say: "speakBp", fmt: (r) => `${r.sys}/${r.dia} mmHg` },
  spo2: { type: "spo2", keys: ["spo2", "pulse"], labels: { spo2: "spo2lbl", pulse: "pulse" }, instr: "instrSpo2", say: "speakSpo2", fmt: (r) => `${r.spo2}% · ${r.pulse} bpm` },
  temp: { type: "temp", keys: ["c"], labels: { c: "tempC" }, instr: "instrTemp", say: "speakTemp", fmt: (r) => `${r.c} °C` },
};
export default function reading(el, app, key) {
  const { t, state } = app, c = CFG[key];
  let buf = []; // last 10 valid live readings
  el.innerHTML = `<h2>${t(key)}</h2><p>${t(c.instr)}</p>
    <div class="card"><p class="note" id="st"></p>
    <p class="live">${key === "spo2" ? '<span class="heart" id="heart" aria-hidden="true">❤</span> ' : ""}<span id="live" aria-live="polite">${t("waiting")}</span></p>
    <div class="row"><button class="pill ghost" id="dev">${t("connect")}</button><button class="pill" id="lock" disabled>${t("lock")}</button></div></div>
    <p><strong>${t("manual")}</strong></p>
    <div class="fields">${c.keys.map((k) => `<div><label for="f-${k}">${t(c.labels[k])}</label><input id="f-${k}" type="number" inputmode="decimal" step="any"></div>`).join("")}</div>
    <p class="err" id="err" role="alert"></p>
    <div class="row"><button class="pill ghost" id="back">${t("back")}</button><button class="pill" id="save">${t("save")}</button></div>`;
  const $ = (s) => el.querySelector(s);
  const showStatus = () => {
    const k = isDemo() ? "stDemo" : !serialSupported() ? "stUnsupported" : status() === "connected" ? "stConnected" : "stDisconnected";
    $("#st").textContent = t(k);
  };
  showStatus();
  if (isDemo() || !serialSupported()) $("#dev").hidden = true;
  $("#dev").onclick = () => connect();
  const off = subscribe((m) => {
    if (m.status) return showStatus();
    if (m.r.type !== c.type) return;
    if (!m.ok) { $("#err").textContent = t("bad"); return; }
    $("#err").textContent = "";
    buf = [...buf, m.r].slice(-10);
    $("#live").textContent = c.keys.filter((k) => m.r[k] != null).map((k) => `${t(c.labels[k])}: ${m.r[k]}`).join(" · ");
    if (key === "spo2") $("#heart").style.animationDuration = 60 / m.r.pulse + "s";
    $("#lock").disabled = buf.length < 5; // need a few values before averaging
  });
  const finish = (r) => { state.readings[key] = { ...r, text: c.fmt(r) }; off(); app.go("menu"); };
  $("#lock").onclick = () => { // average of the last ~10 values
    const r = { type: c.type };
    c.keys.forEach((k) => {
      const vals = buf.map((b) => b[k]).filter(Number.isFinite);
      if (vals.length) { const m = vals.reduce((a, b) => a + b, 0) / vals.length; r[k] = k === "c" ? +m.toFixed(1) : Math.round(m); }
    });
    finish(r);
  };
  $("#save").onclick = () => {
    const r = manual.read(c.type, Object.fromEntries(c.keys.map((k) => [k, $("#f-" + k).value])));
    if (!r) { $("#err").textContent = t("bad"); return; }
    finish(r);
  };
  $("#back").onclick = () => app.go("menu");
  app.face.set("listening"); app.speak(t(c.say));
  return off; // router calls this when leaving the screen
}
