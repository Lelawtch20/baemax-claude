// spo2.js - spo2 screen; the layout is in reading.js.
import reading from "./reading.js";
export default (el, app) => reading(el, app, "spo2");
