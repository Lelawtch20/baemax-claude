// skin.js - Screen 10: camera preview, capture, classifier, top-3 with bars.
// Privacy: the frame is drawn to a hidden canvas, classified, then wiped. Nothing is saved or uploaded.
import { loadModel, classify, isSimulated, DEMO_RESULT, THRESHOLD } from "../engine/classifier.js";
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => "&#" + c.charCodeAt(0) + ";");
export default function skin(el, app) {
  const { t, state } = app;
  let stream = null, gone = false, demo = isSimulated(), res = null;
  el.innerHTML = `<h2>${t("skin")}</h2><p>${t("skinInstr")}</p>
    <div class="cam"><video id="v" autoplay playsinline muted></video><div class="guide" aria-hidden="true"></div></div>
    <canvas id="c" hidden></canvas><p class="err" id="err" role="alert"></p><div id="out" aria-live="polite"></div>
    <div class="row"><button class="pill ghost" id="back">${t("back")}</button>
    <button class="pill" id="cap" disabled>${t("capture")}</button>
    <button class="pill ghost" id="again" hidden>${t("retake")}</button>
    <button class="pill ghost" id="demo" hidden>${t("demoMode")}</button>
    <button class="pill" id="save" hidden>${t("save")}</button></div>`;
  const $ = (s) => el.querySelector(s);
  function show(r) {
    res = r; const top = r[0], sure = top.p >= THRESHOLD;
    $("#out").innerHTML = (demo ? `<p class="note">${t("demoBadge")}</p>` : "") + `<div class="card">`
      + (sure ? `<p>${t("similar")}: <strong>${esc(top.label)}</strong></p>` : `<p><strong>${t("skinUnsure")}</strong></p>`)
      + r.map((x) => `<div class="bar"><span>${esc(x.label)}</span><div class="track"><i style="width:${Math.round(x.p * 100)}%"></i></div><b>${Math.round(x.p * 100)}%</b></div>`).join("") + `</div>`;
    $("#cap").hidden = true; $("#again").hidden = false; $("#save").hidden = false; app.face.set(sure ? "idle" : "concerned");
  }
  function noModel() { $("#out").innerHTML = `<p class="note">${t("modelMissing")}</p>`; $("#demo").hidden = false; }
  $("#cap").onclick = async () => {
    const v = $("#v"), c = $("#c"), s = Math.min(v.videoWidth, v.videoHeight);
    if (!s) return;
    c.width = c.height = 224; // size the model expects
    c.getContext("2d").drawImage(v, (v.videoWidth - s) / 2, (v.videoHeight - s) / 2, s, s, 0, 0, 224, 224);
    $("#out").textContent = t("analyzing"); app.face.set("thinking");
    try { show(demo ? DEMO_RESULT : await classify(c)); } catch (e) { noModel(); app.face.set("idle"); }
    c.width = 0; // discard the image
  };
  $("#again").onclick = () => { $("#out").textContent = ""; $("#cap").hidden = false; $("#again").hidden = true; $("#save").hidden = true; app.face.set("listening"); };
  $("#demo").onclick = () => { demo = true; $("#demo").hidden = true; show(DEMO_RESULT); };
  $("#save").onclick = () => {
    const top = res[0];
    state.readings.skin = { text: top.p >= THRESHOLD ? `${t("similar")}: ${top.label}` : t("notSure"), confidence: top.p };
    app.go("menu");
  };
  $("#back").onclick = () => app.go("menu");
  navigator.mediaDevices?.getUserMedia({ video: true, audio: false }).then((s) => {
    if (gone) return s.getTracks().forEach((x) => x.stop());
    stream = s; $("#v").srcObject = s; $("#cap").disabled = false;
  }).catch(() => { $("#err").textContent = t("camDenied"); });
  if (!demo) loadModel().catch(() => { if (!gone) noModel(); });
  app.face.set("listening"); app.speak(t("speakSkin"));
  return () => { gone = true; stream?.getTracks().forEach((x) => x.stop()); };
}
