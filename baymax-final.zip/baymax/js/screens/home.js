// home.js - Screen 1: title, greeting, Begin button.
import { CONFIG } from "../config.js";
export default function home(el, app) {
  const { t } = app;
  el.innerHTML = `<div class="center"><h1>${CONFIG.TITLE}</h1><p>${t("tagline")}</p>
    <div class="row"><button class="pill" id="go">${t("begin")}</button></div></div>`;
  el.querySelector("#go").onclick = () => app.go("consent");
  app.face.set("happy");
  app.speak(t("hello"));
}
