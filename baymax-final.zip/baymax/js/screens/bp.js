// bp.js - bp screen; the layout is in reading.js.
import reading from "./reading.js";
export default (el, app) => reading(el, app, "bp");
