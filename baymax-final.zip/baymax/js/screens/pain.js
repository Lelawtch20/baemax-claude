// pain.js - Screen 4: pain 1-10 with faces + optional symptom chips. Stored in app.state.
const ICONS = ["😀", "🙂", "🙂", "😐", "😐", "😕", "😟", "😣", "😖", "😭"];
const SYM = ["fever", "cough", "headache", "dizziness", "nausea", "breath", "none"];
export default function pain(el, app) {
  const { t, state } = app;
  el.innerHTML = `<h2>${t("painQ")}</h2>
    <div class="pains" role="group" aria-label="${t("painQ")}">${ICONS.map((ic, i) => `<button class="tile pn" data-n="${i + 1}" aria-pressed="${state.pain === i + 1}" aria-label="${i + 1}"><span aria-hidden="true">${ic}</span><strong>${i + 1}</strong></button>`).join("")}</div>
    <p><strong>${t("symTitle")}</strong></p>
    <div class="chips">${SYM.map((s) => `<button class="chip" data-s="${s}" aria-pressed="${state.symptoms.includes(s)}">${t("sym_" + s)}</button>`).join("")}</div>
    <div class="row"><button class="pill ghost" id="back">${t("back")}</button><button class="pill" id="next"${state.pain ? "" : " disabled"}>${t("next")}</button></div>`;
  const next = el.querySelector("#next");
  el.querySelectorAll(".pn").forEach((b) => (b.onclick = () => {
    state.pain = +b.dataset.n; next.disabled = false;
    el.querySelectorAll(".pn").forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
    app.face.set(state.pain >= 7 ? "concerned" : "listening");
  }));
  el.querySelectorAll(".chip").forEach((b) => (b.onclick = () => {
    const s = b.dataset.s, on = state.symptoms.includes(s);
    state.symptoms = on ? state.symptoms.filter((x) => x !== s) : s === "none" ? ["none"] : [...state.symptoms.filter((x) => x !== "none"), s];
    el.querySelectorAll(".chip").forEach((x) => x.setAttribute("aria-pressed", String(state.symptoms.includes(x.dataset.s))));
  }));
  el.querySelector("#back").onclick = () => app.go("patient");
  next.onclick = () => app.go("menu");
  app.face.set(state.pain >= 7 ? "concerned" : "listening"); app.speak(t("painQ"));
}
