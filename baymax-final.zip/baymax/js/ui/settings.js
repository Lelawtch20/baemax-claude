// settings.js - hidden settings dialog (tap the Baymax face 5 times).
// Demo mode, device connect, voice, text size, simulated camera model, and a read-only threshold viewer.
import { isDemo, setDemo, connect, serialSupported, status } from "../sensors/hub.js";
import { isMuted, setMuted } from "./speech.js";
import { isSimulated, setSimulate } from "../engine/classifier.js";
import { T, BMI_CUTOFFS } from "../engine/thresholds.js";
const SIZES = [18, 22, 26, 30]; // text size choices in px (edit here)
let sizeIdx = 1;
export function openSettings(app) {
  const { t } = app, d = document.createElement("dialog");
  const row = (id, label, on) => `<div class="set-row"><span>${label}</span><button class="pill small" id="${id}" aria-pressed="${on}">${t(on ? "on" : "off")}</button></div>`;
  const thr = JSON.stringify({ ...T, bmi: BMI_CUTOFFS.map((c) => `${c.key}: below ${c.max}`) }, null, 1);
  d.innerHTML = `<h2>${t("setTitle")}</h2>${row("demo", t("setDemo"), isDemo())}${row("voice", t("setVoice"), !isMuted())}${row("sim", t("setSim"), isSimulated())}
    <div class="set-row"><span>${t("setFont")}</span><span><button class="pill small" id="fm" aria-label="Smaller text">A-</button> <button class="pill small" id="fp" aria-label="Larger text">A+</button></span></div>
    <div class="set-row"><button class="pill small" id="dev">${t("connect")}</button><span id="st"></span></div>
    <p><strong>${t("setThr")}</strong></p><pre tabindex="0">${thr}</pre>
    <div class="row"><button class="pill" id="x">${t("setClose")}</button></div>`;
  const $ = (s) => d.querySelector(s);
  const flip = (id, on) => { $(id).setAttribute("aria-pressed", String(on)); $(id).textContent = t(on ? "on" : "off"); };
  const refresh = () => {
    $("#dev").disabled = isDemo() || !serialSupported();
    $("#st").textContent = t(isDemo() ? "stDemo" : !serialSupported() ? "stUnsupported" : status() === "connected" ? "stConnected" : "stDisconnected");
  };
  $("#demo").onclick = () => { setDemo(!isDemo()); flip("#demo", isDemo()); refresh(); };
  $("#voice").onclick = () => { setMuted(!isMuted()); flip("#voice", !isMuted()); app.chrome(); };
  $("#sim").onclick = () => { setSimulate(!isSimulated()); flip("#sim", isSimulated()); };
  const size = (n) => { sizeIdx = Math.min(SIZES.length - 1, Math.max(0, sizeIdx + n)); document.documentElement.style.fontSize = SIZES[sizeIdx] + "px"; };
  $("#fm").onclick = () => size(-1); $("#fp").onclick = () => size(1);
  $("#dev").onclick = () => connect().then(refresh);
  $("#x").onclick = () => d.close();
  d.onclose = () => d.remove();
  refresh(); document.body.append(d); d.showModal();
}
