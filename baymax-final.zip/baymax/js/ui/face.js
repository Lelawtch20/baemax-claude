// face.js - Baymax face drawn in pure SVG (no images). Styling is in styles.css.
// Use: const face = mountFace(element); face.set("thinking");
// Expressions: idle, listening, thinking, happy, concerned, alert
const SVG = `<svg class="face" viewBox="0 0 200 130" aria-hidden="true">
<rect x="4" y="4" width="192" height="122" rx="60" fill="#fff" stroke-width="4"/>
<line x1="68" y1="65" x2="132" y2="65" stroke="#1F2328" stroke-width="3"/>
<g class="eye l"><ellipse class="blink" cx="64" cy="65" rx="11" ry="15" fill="#1F2328"/></g>
<g class="eye r"><ellipse class="blink" cx="136" cy="65" rx="11" ry="15" fill="#1F2328"/></g></svg>`;

export function mountFace(host) {
  host.innerHTML = SVG;
  const svg = host.firstElementChild;
  svg.style.setProperty("--b", (3 + Math.random() * 2).toFixed(1) + "s"); // blink every 3-5 s
  svg.dataset.e = "idle";
  return { set(expression) { svg.dataset.e = expression; } };
}
