// speech.js - Baymax's voice using the browser's built-in speechSynthesis.
// Note: Chrome only allows speech after the user has tapped the page once.
let muted = false;
export const isMuted = () => muted;
export function setMuted(v) {
  muted = v;
  if (v && "speechSynthesis" in window) speechSynthesis.cancel();
}
export function speak(text, lang = "en") {
  if (muted || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = lang === "fil" ? "fil-PH" : "en-US";
  u.rate = 0.9;   // calm and slow
  u.pitch = 1;
  speechSynthesis.speak(u);
}
