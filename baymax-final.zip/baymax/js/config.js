// config.js - the one place to edit project settings.
export const CONFIG = {
  TITLE: "B.A.Y.M.A.X",     // capstone title shown on the Home screen
  IDLE_MS: 5 * 60 * 1000,   // inactivity timeout: wipe data after 5 minutes
  DEMO_MODE: false,         // true = simulated sensors (or open the page with ?demo at the end of the address)
  EMERGENCY_NUMBER: "911",  // Philippines
  LLM_ENDPOINT: "",         // optional online advice (step 5). Never put API keys here.
};
