// validate.js - plausibility filter shared by ALL sensor providers.
// Edit LIMITS if your sensors have a different valid range.
export const LIMITS = { spo2: [70, 100], pulse: [30, 220], temp: [30, 43], sys: [70, 250], dia: [40, 150] };
const ok = (k, v) => Number.isFinite(v) && v >= LIMITS[k][0] && v <= LIMITS[k][1];
// Returns the reading if possible, or null if impossible (bad data is rejected).
export function check(r) {
  if (r.type === "spo2") return ok("spo2", r.spo2) && ok("pulse", r.pulse) ? r : null;
  if (r.type === "temp") return ok("temp", r.c) ? r : null;
  if (r.type === "bp") {
    const pulseOk = r.pulse == null || ok("pulse", r.pulse);
    return ok("sys", r.sys) && ok("dia", r.dia) && r.sys > r.dia && pulseOk ? r : null;
  }
  return null;
}
