// serial.js - SerialProvider: Web Serial (Chrome) reading newline-delimited JSON from an ESP32 at 115200 baud.
// Lines look like {"type":"spo2","spo2":97,"pulse":78}. Malformed lines are ignored.
export class SerialProvider {
  constructor(emit, onStatus) {
    this.emit = emit; this.onStatus = onStatus; this.status = "disconnected"; this.port = null;
    if ("serial" in navigator) navigator.serial.addEventListener("disconnect", () => this.setStatus("disconnected"));
  }
  setStatus(s) { this.status = s; this.onStatus(s); }
  async connect() { // must be called from a tap (browser rule)
    if (!("serial" in navigator)) return this.setStatus("unsupported");
    try {
      this.port = await navigator.serial.requestPort();
      await this.port.open({ baudRate: 115200 });
      this.setStatus("connected");
      this.loop();
    } catch (e) { this.setStatus("disconnected"); }
  }
  async loop() {
    const dec = new TextDecoderStream();
    this.port.readable.pipeTo(dec.writable).catch(() => {});
    const reader = dec.readable.getReader();
    let buf = "";
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += value;
        let i;
        while ((i = buf.indexOf("\n")) >= 0) { this.parse(buf.slice(0, i).trim()); buf = buf.slice(i + 1); }
      }
    } catch (e) { /* unplugged or read error */ }
    this.setStatus("disconnected");
  }
  parse(line) {
    try { const o = JSON.parse(line); if (o && typeof o.type === "string") this.emit(o); } catch (e) { /* ignore */ }
  }
}
