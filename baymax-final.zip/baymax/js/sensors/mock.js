// mock.js - MockProvider (Demo mode): fake readings with slight noise, once per second.
export class MockProvider {
  constructor(emit) { this.emit = emit; this.id = null; }
  start() {
    if (this.id) return;
    const n = (a) => (Math.random() - 0.5) * 2 * a; // noise between -a and +a
    this.id = setInterval(() => {
      this.emit({ type: "spo2", spo2: Math.round(97.5 + n(1)), pulse: Math.round(76 + n(4)) });
      this.emit({ type: "temp", c: +(36.7 + n(0.15)).toFixed(1) });
      this.emit({ type: "bp", sys: Math.round(118 + n(3)), dia: Math.round(76 + n(2)), pulse: Math.round(74 + n(3)) });
    }, 1000);
  }
  stop() { clearInterval(this.id); this.id = null; }
}
