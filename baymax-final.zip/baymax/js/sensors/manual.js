// manual.js - ManualProvider: values typed on screen. read() returns a valid reading or null.
import { check } from "./validate.js";
export class ManualProvider {
  read(type, values) {
    const r = { type };
    for (const k in values) { const s = String(values[k]).trim(); r[k] = s === "" ? null : Number(s); }
    return check(r);
  }
}
