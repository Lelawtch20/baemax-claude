// hub.js - picks the provider (demo or serial), validates every reading, and tells screens.
// Screens call subscribe(fn). fn receives {ok:true,r:reading} | {ok:false,r:badReading} | {status:"connected"...}.
import { CONFIG } from "../config.js";
import { check } from "./validate.js";
import { MockProvider } from "./mock.js";
import { SerialProvider } from "./serial.js";

const subs = new Set();
let demo = CONFIG.DEMO_MODE || new URLSearchParams(location.search).has("demo");
const emit = (r) => { const c = check(r); subs.forEach((f) => f(c ? { ok: true, r: c } : { ok: false, r })); };
const mock = new MockProvider(emit);
const serial = new SerialProvider(emit, (s) => subs.forEach((f) => f({ status: s })));

export const isDemo = () => demo;
export const setDemo = (v) => { demo = v; };
export const serialSupported = () => "serial" in navigator;
export const status = () => serial.status;
export const connect = () => (demo ? Promise.resolve() : serial.connect());
export function subscribe(fn) {
  subs.add(fn);
  if (demo) mock.start();
  return () => { subs.delete(fn); if (!subs.size) mock.stop(); };
}
