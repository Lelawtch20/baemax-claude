// classifier.js - loads the Teachable Machine image model and classifies one canvas.
// Libraries: tries local files in /libs first (works offline), then the CDN. See libs/README.md.
// Model: model/model.json + model/metadata.json (class labels come from the model itself).
export const THRESHOLD = 0.7; // below this confidence, Baymax says "I am not sure"
// Fake results used by demo mode when no model is available.
export const DEMO_RESULT = [
  { label: "Demo: healthy skin", p: 0.82 }, { label: "Demo: minor rash", p: 0.12 }, { label: "Demo: minor cut", p: 0.06 },
];
// Settings can force fake results (no model needed).
let simulated = false;
export const isSimulated = () => simulated;
export const setSimulate = (v) => { simulated = v; };
const LIBS = [
  ["libs/tf.min.js", "https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@1.3.1/dist/tf.min.js"],
  ["libs/teachablemachine-image.min.js", "https://cdn.jsdelivr.net/npm/@teachablemachine/image@0.8.5/dist/teachablemachine-image.min.js"],
];
let model = null;
function loadScript([src, ...fallbacks]) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src; s.onload = resolve;
    s.onerror = () => (fallbacks.length ? loadScript(fallbacks).then(resolve, reject) : reject(new Error("script")));
    document.head.append(s);
  });
}
export async function loadModel() {
  if (model) return model;
  if (!window.tmImage) for (const l of LIBS) await loadScript(l);
  model = await window.tmImage.load("model/model.json", "model/metadata.json");
  return model;
}
// Returns the top 3 as [{label, p}] sorted by confidence. Throws if the model cannot load.
export async function classify(canvas) {
  if (simulated) return DEMO_RESULT;
  const m = await loadModel();
  const out = await m.predict(canvas);
  return out.map((x) => ({ label: x.className, p: x.probability })).sort((a, b) => b.p - a.p).slice(0, 3);
}
