// assess.js - the deterministic rules engine (source of truth). Edit numbers in thresholds.js, not here.
// Returns {items:[{key,value,status,code,counts}], overall:"normal"|"attention"|"urgent"}.
// status: normal | caution | urgent. Items with counts:false (BMI, skin) are shown but never change the overall level.
import { T, bmiClass } from "./thresholds.js";
const RANK = { normal: 0, low: 1, high: 1, urgent: 2 };
export function assess(state) {
  const items = [], r = state.readings;
  const add = (key, value, status, code, counts = true) => items.push({ key, value, status, code, counts });
  if (r.bp) {
    const { sys, dia } = r.bp, b = T.bp;
    const code = sys > b.crisisSys || dia > b.crisisDia ? "crisis"
      : sys >= b.high2Sys || dia >= b.high2Dia ? "high2"
      : sys >= b.high1Sys || dia >= b.high1Dia ? "high1"
      : sys < b.lowSys || dia < b.lowDia ? "low"
      : sys >= b.elevatedSys ? "elevated" : "normal";
    add("bp", `${sys}/${dia} mmHg`, code === "crisis" ? "urgent" : code === "normal" ? "normal" : "caution", code);
  }
  const ps = [r.spo2?.pulse, r.bp?.pulse].filter(Number.isFinite);
  if (ps.length) {
    const w = ps.map((p) => ({ p, c: p > T.pulse.urgent ? "urgent" : p > T.pulse.high ? "high" : p < T.pulse.low ? "low" : "normal" }))
      .sort((a, b) => RANK[b.c] - RANK[a.c])[0];
    add("pulse", `${w.p} bpm`, w.c === "urgent" ? "urgent" : w.c === "normal" ? "normal" : "caution", w.c);
  }
  if (r.spo2) {
    const s = r.spo2.spo2, o = T.spo2;
    const code = s < o.urgent ? "urgent" : s < o.borderline ? "low" : s < o.normal ? "border" : "normal";
    add("spo2", `${s}%`, code === "urgent" ? "urgent" : code === "normal" ? "normal" : "caution", code);
  }
  if (r.temp) {
    const c = r.temp.c, o = T.temp;
    const code = c < o.lowUrgent ? "low" : c < o.normalLow ? "cool" : c <= o.normalHigh ? "normal"
      : c < o.fever ? "slight" : c < o.highFever ? "fever" : "high";
    add("temp", `${c} °C`, code === "low" || code === "high" ? "urgent" : code === "normal" ? "normal" : "caution", code);
  }
  if (r.bmi) { const k = bmiClass(r.bmi.bmi); add("bmi", String(r.bmi.bmi), k === "normalBmi" ? "normal" : "caution", k, false); }
  if (state.pain) {
    const urgent = state.pain >= T.pain.urgent && state.symptoms.some((s) => T.pain.urgentSymptoms.includes(s));
    const code = urgent ? "urgent" : state.pain >= 8 ? "high" : state.pain >= 4 ? "mod" : "mild";
    add("pain", `${state.pain}/10`, urgent ? "urgent" : code === "mild" ? "normal" : "caution", code);
  }
  if (r.skin) add("skin", r.skin.text, "caution", "demo", false);
  const overall = items.some((i) => i.status === "urgent") ? "urgent"
    : items.some((i) => i.counts && i.status !== "normal") ? "attention" : "normal";
  return { items, overall };
}
