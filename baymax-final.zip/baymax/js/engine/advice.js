// advice.js - getAdvice(summary, lang) -> array of short sentences.
// Offline mode (default) uses templates. Online mode runs only if CONFIG.LLM_ENDPOINT is set.
// SECURITY: NEVER put an API key in this file or config.js (anyone can read it). Point
// LLM_ENDPOINT at a small proxy server that holds the key. Only the anonymized summary is sent.
// The engine's urgency level is never changed by the AI: urgent cases never reach this function.
import { CONFIG } from "../config.js";
import { tx } from "./text.js";
const SYSTEM = "You are Baymax, a gentle health companion. Give preliminary guidance only. Never diagnose. Never name prescription drugs or doses. Follow the given urgency level and never downgrade it. Include a line to see a healthcare professional. Under 150 words, simple language.";

export function offlineAdvice(s, lang) {
  const out = [tx(lang, "adv_" + s.overall)];
  s.readings.filter((r) => r.status !== "normal").forEach((r) => {
    const tip = tx(lang, "tip_" + r.key);
    if (tip !== "tip_" + r.key && !out.includes(tip)) out.push(tip);
  });
  out.push(tx(lang, "adv_general"), tx(lang, "adv_warn"), tx(lang, "adv_pro"));
  return out;
}
export async function getAdvice(s, lang) {
  if (CONFIG.LLM_ENDPOINT && s.overall !== "urgent") {
    try {
      const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 8000);
      const res = await fetch(CONFIG.LLM_ENDPOINT, { method: "POST", signal: ctl.signal, headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ system: SYSTEM, summary: s, language: lang }) });
      clearTimeout(timer);
      const j = await res.json();
      if (typeof j.advice === "string" && j.advice.trim()) return j.advice.match(/[^.!?]+[.!?]*/g).map((x) => x.trim());
    } catch (e) { /* silently fall back to offline */ }
  }
  return offlineAdvice(s, lang);
}
