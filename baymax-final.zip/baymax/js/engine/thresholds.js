// thresholds.js - editable cutoffs. A nurse should validate these (full set added in step 3).
// BMI uses Asia-Pacific cutoffs: first row whose "max" is above the BMI wins.
export const BMI_CUTOFFS = [
  { max: 18.5, key: "underweight" },
  { max: 23, key: "normalBmi" },
  { max: 25, key: "overweight" },
  { max: 30, key: "obese1" },
  { max: Infinity, key: "obese2" },
];
export const bmiClass = (b) => BMI_CUTOFFS.find((c) => b < c.max).key;

// ===== Clinical thresholds (adults). A NURSE SHOULD VALIDATE THESE before real use. =====
export const T = {
  bp: { crisisSys: 180, crisisDia: 120, high2Sys: 140, high2Dia: 90, high1Sys: 130, high1Dia: 80, elevatedSys: 120, lowSys: 90, lowDia: 60 },
  pulse: { low: 60, high: 100, urgent: 130 },            // resting
  spo2: { normal: 95, borderline: 92, urgent: 90 },
  temp: { lowUrgent: 35.0, normalLow: 36.1, normalHigh: 37.2, fever: 38.0, highFever: 39.5 },
  pain: { urgent: 8, urgentSymptoms: ["breath", "dizziness"] }, // pain 8-10 + one of these = urgent
};
