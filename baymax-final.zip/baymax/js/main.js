// main.js - router + shared state. Screens are in js/screens/ and each is
// a function (element, app). To add a screen: import it and add it to SCREENS.
import { CONFIG } from "./config.js";
import { mountFace } from "./ui/face.js";
import { speak, setMuted, isMuted } from "./ui/speech.js";
import { t, getLang, setLang } from "./ui/i18n.js";
import home from "./screens/home.js";
import consent from "./screens/consent.js";
import patient from "./screens/patient.js";
import menu from "./screens/menu.js";
import pain from "./screens/pain.js";
import bp from "./screens/bp.js";
import spo2 from "./screens/spo2.js";
import temp from "./screens/temp.js";
import bmi from "./screens/bmi.js";
import results from "./screens/results.js";
import emergency from "./screens/emergency.js";
import skin from "./screens/skin.js";
import { openSettings } from "./ui/settings.js";

const SCREENS = { home, consent, patient, pain, menu, bp, spo2, temp, bmi, results, emergency, skin };
// All patient data lives in this object, in memory only. reset() wipes it.
const blank = () => ({ patient: null, readings: {}, pain: null, symptoms: [], satisfied: null, draft: null });
const state = blank();
let current = "home", idle, cleanup;

const root = document.getElementById("screen");
const face = mountFace(document.getElementById("face"));
const langBtn = document.getElementById("lang");
const muteBtn = document.getElementById("mute");
const app = { state, face, t, go, reset, chrome, speak: (text) => speak(text, getLang()) };

function go(name) {
  if (typeof cleanup === "function") cleanup(); // screens may return a cleanup function
  current = name;
  document.body.classList.toggle("home", name === "home");
  face.set("idle");
  const el = document.createElement("section");
  el.className = "screen";
  root.replaceChildren(el);
  cleanup = SCREENS[name](el, app);
  root.focus({ preventScroll: true });
}
function reset() { Object.assign(state, blank()); go("home"); }

function chrome() {
  const toFil = getLang() === "en";
  langBtn.textContent = toFil ? "Filipino" : "English";
  langBtn.setAttribute("aria-label", toFil ? "Switch language to Filipino" : "Switch language to English");
  muteBtn.textContent = (isMuted() ? "🔇 " : "🔊 ") + (isMuted() ? t("unmute") : t("mute"));
  muteBtn.setAttribute("aria-pressed", String(isMuted()));
  document.getElementById("foot").textContent = t("footer");
}
langBtn.onclick = () => { setLang(getLang() === "en" ? "fil" : "en"); chrome(); go(current); };
muteBtn.onclick = () => { setMuted(!isMuted()); chrome(); };

// Privacy: wipe everything after CONFIG.IDLE_MS without a tap or key press.
function poke() {
  clearTimeout(idle);
  idle = setTimeout(() => { if (current !== "home") reset(); }, CONFIG.IDLE_MS);
}
["pointerdown", "keydown"].forEach((e) => addEventListener(e, poke));

chrome(); go("home"); poke();

// Hidden settings: tap the Baymax face 5 times within 3 seconds.
let taps = 0, tapTimer;
document.getElementById("face").addEventListener("click", () => {
  taps++; clearTimeout(tapTimer); tapTimer = setTimeout(() => (taps = 0), 3000);
  if (taps >= 5) { taps = 0; openSettings(app); }
});

// Chrome only allows speech after a tap, so a cover screen collects the first tap and then greets.
const wake = document.createElement("button");
wake.className = "wake"; wake.textContent = t("wake");
wake.onclick = () => { wake.remove(); speak(t("hello"), getLang()); };
document.body.append(wake); wake.focus();
