# Model folder
1. In Teachable Machine (teachablemachine.withgoogle.com) train an Image Project (use at least 50+ varied images per class).
2. Click Export Model > Tensorflow.js > Download (not Upload).
3. Unzip and copy model.json, metadata.json and weights.bin into THIS folder.
4. Reload the app. Class names come from metadata.json automatically.
No model yet? The skin screen offers a demo mode with fake results.
